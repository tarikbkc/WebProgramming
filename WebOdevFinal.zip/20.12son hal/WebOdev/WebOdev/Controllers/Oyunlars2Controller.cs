﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebOdev.Data;
using WebOdev.Models;

namespace WebOdev.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Oyunlars2Controller : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public Oyunlars2Controller(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Oyunlars2
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Oyunlar>>> Getoyunlars()
        {
            return await _context.oyunlars.ToListAsync();
        }

        // GET: api/Oyunlars2/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Oyunlar>> GetOyunlar(int id)
        {
            var oyunlar = await _context.oyunlars.FindAsync(id);

            if (oyunlar == null)
            {
                return NotFound();
            }

            return oyunlar;
        }

        // PUT: api/Oyunlars2/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOyunlar(int id, Oyunlar oyunlar)
        {
            if (id != oyunlar.OyunID)
            {
                return BadRequest();
            }

            _context.Entry(oyunlar).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OyunlarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Oyunlars2
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Oyunlar>> PostOyunlar(Oyunlar oyunlar)
        {
            _context.oyunlars.Add(oyunlar);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOyunlar", new { id = oyunlar.OyunID }, oyunlar);
        }

        // DELETE: api/Oyunlars2/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOyunlar(int id)
        {
            var oyunlar = await _context.oyunlars.FindAsync(id);
            if (oyunlar == null)
            {
                return NotFound();
            }

            _context.oyunlars.Remove(oyunlar);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OyunlarExists(int id)
        {
            return _context.oyunlars.Any(e => e.OyunID == id);
        }
    }
}
