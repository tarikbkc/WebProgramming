﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebOdev.Data;
using WebOdev.Models;
namespace WebOdev.Controllers
{
    public class OyunlarController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OyunlarController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var oyunlar = _context.oyunlars.ToList();//oyunları listeliyor.

            return View(oyunlar);
        }
        OyunYorum oyorum = new OyunYorum();
        public ActionResult OyunDetay(int id)
        {
           
            //var oyunBul = _context.oyunlars.Where(x => x.OyunID == id).ToList();
           oyorum.OyunDeger=_context.oyunlars.Where(x => x.OyunID == id).ToList();
            oyorum.YorumDeger = _context.yorumlars.Where(x => x.Oyunid == id).ToList();
            return View(oyorum);

        }

      
    }
}
