﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebOdev.Data.Migrations
{
    public partial class CreateOyunTuruColumnoyunlarsTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "OyunTuru",
                table: "oyunlars",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OyunTuru",
                table: "oyunlars");
        }
    }
}
