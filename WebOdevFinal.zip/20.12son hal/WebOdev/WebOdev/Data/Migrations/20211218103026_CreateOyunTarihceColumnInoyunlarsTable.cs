﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebOdev.Data.Migrations
{
    public partial class CreateOyunTarihceColumnInoyunlarsTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "OyunTarihce",
                table: "oyunlars",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OyunTarihce",
                table: "oyunlars");
        }
    }
}
