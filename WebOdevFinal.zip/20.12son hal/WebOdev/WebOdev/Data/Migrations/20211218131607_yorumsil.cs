﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebOdev.Data.Migrations
{
    public partial class yorumsil : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_yorumlars_oyunlars_OyunlarOyunID",
                table: "yorumlars");

            migrationBuilder.DropIndex(
                name: "IX_yorumlars_OyunlarOyunID",
                table: "yorumlars");

            migrationBuilder.DropColumn(
                name: "OyunlarOyunID",
                table: "yorumlars");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "OyunlarOyunID",
                table: "yorumlars",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_yorumlars_OyunlarOyunID",
                table: "yorumlars",
                column: "OyunlarOyunID");

            migrationBuilder.AddForeignKey(
                name: "FK_yorumlars_oyunlars_OyunlarOyunID",
                table: "yorumlars",
                column: "OyunlarOyunID",
                principalTable: "oyunlars",
                principalColumn: "OyunID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
